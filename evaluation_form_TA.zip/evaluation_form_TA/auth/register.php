<?php

$db = mysqli_connect("localhost","root","","ta_evaluation_form");

if(!$db)
{ 
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['registerbtn']))
{	$fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $ID=$_POST['ID'];
    $email = $_POST['email'];
    $password = sha1($_POST['psw']);
    $permission=$_POST['permission'];
if($permission=='user')
   { $insert = mysqli_query($db,"INSERT INTO `users`(`fname`, `lname`,`ID`,`email`,`password`,`permission`) VALUES ('$fname','$lname','$ID','$email','$password',0)");
}
else{
    $insert = mysqli_query($db,"INSERT INTO `users`(`fname`, `lname`,`ID`,`email`,`password`,`permission`) VALUES ('$fname','$lname','$ID','$email','$password',1)");
   }
   header("LOCATION:../auth/login.html");
}
else{
    echo "no";
}
mysqli_close($db); // Close connection
?>

