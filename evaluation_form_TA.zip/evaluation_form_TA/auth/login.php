<?php
$user = $_POST['email'];
$pass = sha1($_POST['psw']);

$con = mysqli_connect("localhost", "root", "", "ta_evaluation_form");
$q = "SELECT * FROM `users` WHERE `email`='$user' AND `password`='$pass'";
$mysq = mysqli_query($con, $q);
$aff = mysqli_fetch_assoc($mysq);

if (isset($aff)) {

    session_start();
    $_SESSION['user'] = $aff;
if($aff['permission']==0)
    {header("Location:../Form/evaluation_Form.php");}
    else{
        header("Location:../permission/admin.html");
    }
} else {

    header("Location:../auth/login.html");
}

?>

