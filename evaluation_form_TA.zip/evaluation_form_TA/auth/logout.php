<?php
session_start();
session_destroy();

header("LOCATION:../auth/login.html");