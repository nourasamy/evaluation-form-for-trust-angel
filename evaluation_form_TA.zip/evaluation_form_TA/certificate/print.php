<?php
 session_start();

if(empty($_SESSION['user'])){
    session_destroy();
    header("LOCATION:../auth/login.html");
}
?>
<head>
    <title>&#127881; Concratulation</title>
    <h1>Concratulation &#127881;</h1>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../style/style_print.css">
</head>
 
<body>
    <form name="myForm">
        <br>
        <h2>We proud of you Mr/s : </h2><br>
        <h1><b>
            <?php
            $date = $_POST["date"];
            $con = mysqli_connect("localhost", "root", "", "ta_evaluation_form");
            $q="SELECT `em_id` , MAX( Rank ) AS max FROM `evaluation_form` WHERE `Date`='$date' GROUP BY `em_id` order by max DESC ";
            $rowSQL = mysqli_query($con,$q );
            $row = mysqli_fetch_assoc($rowSQL);
            $largestNumber = $row['max'];
            $ID= $row['em_id'];
            $q2="SELECT fname , lname FROM `users` WHERE `ID`='$ID'";
            $rowSQL2 = mysqli_query($con,$q2 );
            $row2 = mysqli_fetch_assoc($rowSQL2);
            $fname = $row2['fname'];
            $lname= $row2['lname'];
            echo $fname." ".$lname ;

            ?></b></h1><br><br><br><br>
        <h4>So pleased to see you accomplishing great things.</h4><br>
        
        <p>Logout  <a href="../auth/login.html">click here</a>.</p>
    </form>
</body>

</html>