<?php
 session_start();

if(empty($_SESSION['user'])){
    session_destroy();
    header("LOCATION:../auth/login.html");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Employee of Month</title>
    <h1>Employee of Month</h1>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../style/c.css">
</head>

<body>
    <form name="myForm" action="../Form/create.php" method="POST">
        <fieldset>
            <label for="ID">Full ID of employee being evaluated:</label>
            <input type="number" id="ID" name="ID" required><br><br>
            <label for="date">Date :</label>
            <input type="month" id="date" name="date" required>
            <table style="width:100%">
                <tr>
                    <th></th>
                    <th>25%</th>
                    <th>50%</th>
                    <th>75%</th>
                    <th>100%</th>
                </tr>
                <tr>
                    <td> This person takes his OR her work seriously.
                    </td>
                    <td>
                        <div>
                            <input type="radio" id="25" name="Q1" value="25" required>
                        </div>
                    </td>
                    <td>
                        <div>
                            <input type="radio" id="50" name="Q1" value="50" required>
                        </div>
                    </td>
                    <td>
                        <div>
                            <input type="radio" id="75" name="Q1" value="75" required>
                        </div>
                    </td>
                    <td>
                        <div>
                            <input type="radio" id="100" name="Q1" value=100 required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <tr>
                        <td>
                            This person completes and submits work that supervisors can trust.
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="25" name="Q2" value="25" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="50" name="Q2" value="50" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="75" name="Q2" value="75" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="100" name="Q2" value="100" required>
                            </div>
                        </td>
                    </tr>
                </tr>
                <tr>
                    <td>
                        This person meets his OR her deadlines.
                    </td>
                    <td>
                        <div>
                            <input type="radio" id="25" name="Q3" value="25" required>
                        </div>
                    </td>
                    <td>
                        <div>
                            <input type="radio" id="50" name="Q3" value="50" required>
                        </div>
                    </td>
                    <td>
                        <div>
                            <input type="radio" id="75" name="Q3" value="75" required>
                        </div>
                    </td>
                    <td>
                        <div>
                            <input type="radio" id="100" name="Q3" value="100" required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <tr>
                        <td>
                            This person is open to suggestions and new ideas.
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="25" name="Q4" value="25" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="50" name="Q4" value="50" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="75" name="Q4" value="75" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="100" name="Q4" value="100" required>
                            </div>
                        </td>
                    </tr>
                </tr>
                <tr>
                    <td>
                        This person exhaibits a positive attitude when working as part of a team.
                    </td>
                    <td>
                        <div>
                            <input type="radio" id="25" name="Q5" value="25" required>
                        </div>
                    </td>
                    <td>
                        <div>
                            <input type="radio" id="50" name="Q5" value="50" required>
                        </div>
                    </td>
                    <td>
                        <div>
                            <input type="radio" id="75" name="Q5" value="75" required>
                        </div>
                    </td>
                    <td>
                        <div>
                            <input type="radio" id="100" name="Q5" value="100" required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <tr>
                        <td>
                            This person communicates effectively with peers and supervisors.
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="25" name="Q6" value="25" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="50" name="Q6" value="50" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="75" name="Q6" value="75"required> 
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="100" name="Q6" value="100" required></div>
                        </td>
                    </tr>
                </tr>
                <tr>
                    <tr>
                        <td>
                            This person thinks strategically about how to solve problems.
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="25" name="Q7" value="25" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="50" name="Q7" value="50" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="75" name="Q7" value="75"required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="100" name="Q7" value="100" required>
                            </div>
                        </td>
                    </tr>
                </tr>
                <tr>
                    <tr>
                        <td>
                            This person shows an interest in taking on more responsibilities.
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="25" name="Q8" value="25" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="50" name="Q8" value="50" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="75" name="Q8" value="75" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="100" name="Q8" value="100" required>
                            </div>
                        </td>
                    </tr>
                </tr>
                <tr>
                    <tr>
                        <td>
                            This person goes out of this or her way to further personal knowledge.
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="25" name="Q9" value="25" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="50" name="Q9" value="50" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="75" name="Q9" value="75" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="100" name="Q9" value="100" required>
                            </div>
                        </td>
                    </tr>
                </tr>
                <tr>
                    <tr>
                        <td>
                            This person has improved the quality of his OR her work during this evaluation period.
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="25" name="Q10" value="25" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="50" name="Q10" value="50" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="75" name="Q10" value="75" required>
                            </div>
                        </td>
                        <td>
                            <div>
                                <input type="radio" id="100" name="Q10" value="100" required>
                            </div>
                        </td>
                    </tr>
                </tr>
            </table><br>


            <input type="submit" name="submit" value="Submit" /><br><br>


        </fieldset>
        <p>Logout  <a href="../auth/login.html">click here</a>.</p>
    </form>
</body>

</html>