<?php
 session_start();

if(empty($_SESSION['user'])){
    session_destroy();
    header("LOCATION:../auth/login.html");
}
?>
<?php
$id = $_POST['ID'];
$date = $_POST['date'];
$temp=$_POST['Q1']+$_POST['Q2']+$_POST['Q3']+$_POST['Q4']+$_POST['Q5']+$_POST['Q6']+
$_POST['Q7']+$_POST['Q8']+$_POST['Q9']+$_POST['Q10'];
$rank=$temp/10;

$con = mysqli_connect("localhost", "root", "", "ta_evaluation_form");
$q = "SELECT `Rank` FROM `evaluation_form` WHERE `em_id`='$id'";
$mysq = mysqli_query($con, $q);
$aff = mysqli_fetch_assoc($mysq);
$db = mysqli_connect("localhost","root","","ta_evaluation_form");

if(!$db)
{
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($aff)) {
$new=(int)$aff['Rank']+$rank;
$update = mysqli_query($db,"UPDATE `evaluation_form` SET `Rank`='$new' WHERE `em_id`='$id' AND `Date`='$date'");
}
else{
    $insert = mysqli_query($db,"INSERT INTO `evaluation_form`(`em_id`,`Rank`,`Date`) VALUES ('$id','$rank','$date')");
}

mysqli_close($db); // Close connection
?>
<!DOCTYPE html>
<html>
<head>
    <title>Thank you</title>
    <meta charset="UTF-8">
</head>
<style>
    body {
    /* background: #9c9ea0; */
    background-image: url(../imags/TA.png);
    border: 10px solid black;
    padding: 35px;
    background-repeat: no-repeat;
    background-origin: content-box;
    font-size: 20px;
    width: 90%;
    margin: auto;
    font-family: "times"
}

    h1 {
    font-family: "papyrus";
    text-align: center;
}

    </style>
<body>
<h1>Thank you for your record.</h1>
</body>
<p>Logout  <a href="../auth/login.html">click here</a>.</p>
</html>